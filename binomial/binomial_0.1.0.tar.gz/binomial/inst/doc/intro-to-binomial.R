## ----setup, echo = TRUE--------------------------------------------------
knitr::opts_chunk$set(echo = TRUE, error = TRUE, purl = FALSE)
library(binomial)

