# hw-stat133-lucybrooke

This is a README.md for Workout 03. 

